#REPIC (ENVIRONMENTAL POLICY / INTEGRATED CLIMATE IN R Arcgis Bridge)
#EPIC R Script Wrappings
tool_exec<- function(in_params, out_params){
  ##################################################################################################### 
  ### Define input/output parameters
  #####################################################################################################
  year=in_params[[1]]
  pts_shp = in_params[[2]]
  irrig=in_params[[3]]
  pathfile = in_params[[4]]
  ##################################################################################################### 
  ### Load Data R Object 
  #####################################################################################################
  cat(paste0("\n", "Read Point Shapefile Input Data..", "\n"))
  arc.progress_label("Loading data...")
  arc.progress_pos(40)
  #read shapefile for params 2
  pts1 <- arc.open(pts_shp)
  pts_s <- arc.data2sp(arc.select(pts1))
  ##################################################################################################### 
  ### RUN EPIC IN R - START SIMULATION
  ##################################################################################################### 
  cat(paste0("\n", "Process Data...", "\n"))
  folder<-"C:\\REPIC\\EPIC0810\\"
  ######set starting year of simulation
  EPICCONT<- file(paste('C:\\REPIC\\EPIC0810\\EPICCONT2.DAT', sep=""))
  a_EPICCONT=readLines(EPICCONT)
    y1<-paste(year) 
    y2<-substr(a_EPICCONT[1],9,80)
    ypar<-sprintf("%8s%71s",y1,y2)
    a_EPICCONT[1]<-ypar
  writeLines(as.character(a_EPICCONT), paste('C:\\REPIC\\EPIC0810\\EPICCONT.DAT', sep=" "))
  writeLines(as.character(a_EPICCONT), paste('C:\\REPIC\\EPIC0810\\EPICCONT2.DAT', sep=" "))
  ####condition slope
  pts_s$SL[pts_s$SL<0.01]<-0.01
  ################################################
  ####START RUN
  ################################################
  setwd(folder)
  i<-1
  for (i in 1:NROW(pts_s)){
   if (as.numeric(pts_s$crop[i])>0){
  ######## set the vimx
  #DECIMALS line 4 vimx NIR
  EPICCONT<- file(paste('C:\\REPIC\\EPIC0810\\EPICCONT2.DAT', sep=""))
  a_EPICCONT=readLines(EPICCONT)
  vimx1<-substr(a_EPICCONT[4],1,56)
  vimx2<-substr(a_EPICCONT[4],57,64)  
  vimx2<-as.numeric(pts_s$nir[i])
  vimx2<-substr(sprintf("%4.2f",as.numeric(vimx2)),1,7)
  vimx3<-substr(a_EPICCONT[4],65,80)
  vimxpar<-sprintf("%56s%8s%16s",vimx1,vimx2,vimx3)
  ###CHANGE THE VALUE vimx NIR
  a_EPICCONT[4]<-vimxpar  
  ###########
  ######## set the FMX
  #DECIMALS line 5 FMX NLD
  a_EPICCONT[5]
  fmx1<-substr(a_EPICCONT[5],1,16)
  fmx2<-substr(a_EPICCONT[5],17,24)
  fmx2<-as.numeric(pts_s$nld[i])
  fmx2<-substr(sprintf("%3.2f",as.numeric(fmx2)),1,7)
  fmx3<-substr(a_EPICCONT[5],25,80)
  fmxpar<-sprintf("%16s%8s%56s",fmx1,fmx2,fmx3)  
  ###write file EPICCONTDAT
  a_EPICCONT[5]<-fmxpar
  ###CHANGE THE VALUE FMX NLD
  writeLines(as.character(a_EPICCONT), paste('C:\\REPIC\\EPIC0810\\EPICCONT.DAT', sep=" "))
  close(EPICCONT)
  #-----#FINAL EPICSIT FORMAT
  EPICSIT<- file(paste('C:\\REPIC\\EPIC0810\\EPIC.SIT', sep=""))
  a_EPICSIT=readLines(EPICSIT)
  ###CHANGE THE lat,lot, elev 
  s1<-substr(a_EPICSIT[4],1,8)
  ###lat
  s1<-as.numeric(pts_s$lat[i])
  s1<-substr(sprintf("%2.2f",as.numeric(s1)),1,8)
  s2<-substr(a_EPICSIT[4],9,16)
  ###lot
  s2<-as.numeric(pts_s$lon[i])
  s2<-substr(sprintf("%2.2f",as.numeric(s2)),1,8)
  s3<-substr(a_EPICSIT[4],17,24)
  ###elevation
  s3<-as.numeric(pts_s$elev[i])
  s3<-substr(sprintf("%3.2f",as.numeric(s3)),1,8)
  s4<-substr(a_EPICSIT[4],25,88)
  spar<-sprintf("%8s%8s%8s%64s",s1,s2,s3,s4) 
  a_EPICSIT[4]<-spar
  ###CHANGE THE WSA (ha)
  v1<-substr(a_EPICSIT[5],1,8)
  v1<-as.numeric(pts_s$wsa[i])
  v1<-substr(sprintf("%4.4f",as.numeric(v1)),1,8)
  v2<-substr(a_EPICSIT[5],9,56)
  ###CHANGE THE slope  
  v8<-substr(a_EPICSIT[5],57,64)
  v8<-as.numeric(pts_s$SL[i])
  v8<-substr(sprintf("%1.4f",as.numeric(v8)),1,8)
  v9<-substr(a_EPICSIT[5],65,80)
  vpar<-sprintf("%8s%48s%8s%16s",v1,v2,v8,v9)
     a_EPICSIT[5]<-vpar
     #################################################################################### METHOD OF IRRIGATION
     irr<-as.numeric(irrig)
     if (as.numeric(pts_s$crop[i])==2){ #CEREALS
       ##dryland
       if (irr==0){
          ir1<-substr(a_EPICSIT[6],1,4)
          ir1<-0
          ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
          ir2<-substr(a_EPICSIT[6],5,32)
          irpar<-sprintf("%4s%28s",ir1,ir2)
          a_EPICSIT[6]<-irpar
          }else {
            ##drip irrigation
            ir1<-substr(a_EPICSIT[6],1,4)
            ir1<-15
            ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
            ir2<-substr(a_EPICSIT[6],5,32)
            irpar<-sprintf("%4s%28s",ir1,ir2)
            a_EPICSIT[6]<-irpar  }
       }else if(as.numeric(pts_s$crop[i])==5) {   #OLIVES
         ##dryland
         if (irr==0){ 
           ir1<-substr(a_EPICSIT[6],1,4)
           ir1<-0
           ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
           ir2<-substr(a_EPICSIT[6],5,32)
           irpar<-sprintf("%4s%28s",ir1,ir2)
           a_EPICSIT[6]<-irpar
         }else {
           ##drip irrigation
           ir1<-substr(a_EPICSIT[6],1,4)
           ir1<-15
           ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
           ir2<-substr(a_EPICSIT[6],5,32)
           irpar<-sprintf("%4s%28s",ir1,ir2)
           a_EPICSIT[6]<-irpar  }
       }else if(as.numeric(pts_s$crop[i])==9) {   #WHEAT
         ##dryland
         if (irr==0){ 
           ir1<-substr(a_EPICSIT[6],1,4)
           ir1<-0
           ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
           ir2<-substr(a_EPICSIT[6],5,32)
           irpar<-sprintf("%4s%28s",ir1,ir2)
           a_EPICSIT[6]<-irpar
          } else {
            ##drip irrigation
            ir1<-substr(a_EPICSIT[6],1,4)
            ir1<-15
            ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
            ir2<-substr(a_EPICSIT[6],5,32)
            irpar<-sprintf("%4s%28s",ir1,ir2)
            a_EPICSIT[6]<-irpar  }    
       } else {
         ##sprinkler irrigation
         ir1<-substr(a_EPICSIT[6],1,4)
         ir1<-11
         ir1<-substr(sprintf("%4.0f",as.numeric(ir1)),1,4)
         ir2<-substr(a_EPICSIT[6],5,32)
         irpar<-sprintf("%4s%28s",ir1,ir2)
         a_EPICSIT[6]<-irpar}
         writeLines(as.character(a_EPICSIT), paste('C:\\REPIC\\EPIC0810\\EPIC.SIT', sep=" "))
        close(EPICSIT)
      cat(paste0("\n", "running epic cell number=",i, "\n"))
      shell(paste0("copy /y C:\\REPIC\\DATA\\SOIL\\",as.numeric(pts_s$soil[i]),".sol C:\\REPIC\\EPIC0810\\EPIC.sol"))
      shell(paste0("copy /y C:\\REPIC\\DATA\\METEO\\",as.numeric(pts_s$clima[i]),".DLY C:\\REPIC\\EPIC0810\\TEMP.DLY"))
      shell(paste0("copy /y C:\\REPIC\\DATA\\METEO\\",as.numeric(pts_s$clima[i]),".WP1 C:\\REPIC\\EPIC0810\\TEMP.WP1"))
      shell(paste0("copy /y C:\\REPIC\\CROPS\\",as.numeric(pts_s$crop[i]),".OPS C:\\REPIC\\EPIC0810\\EPIC.OPS"))
      shell("epic0810.exe")
      shell(paste0("copy /y C:\\REPIC\\EPIC0810\\OUTPUT.ANN " ," ",pathfile,"\\",i,".ANN"))
	    shell(paste0("copy /y C:\\REPIC\\EPIC0810\\OUTPUT.ACY " ," ",pathfile,"\\",i,".ACY"))
      shell(paste0("copy /y C:\\REPIC\\EPIC0810\\OUTPUT.MWC " ," ",pathfile,"\\",i,".MFS"))
      i<-i+1
     } }

  ###################################################################################################
  ### END OF SIMULATION 
  #####################################################################################################
  arc.progress_label("END OF SIMULATION")
  cat(paste0("\n", "END OF SIMULATION", "\n"))
  arc.progress_pos(80)
  return(out_params)
}



