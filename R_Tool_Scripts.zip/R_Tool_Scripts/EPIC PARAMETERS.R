#PARAMETER CHANGE IN EPICCONT.DAT AND PARM.DAT FILES FOR THE
#R_EPIC (ENVIRONMENTAL POLICY / INTEGRATED CLIMATE IN R Arcgis Bridge)
#EPIC R Script Wrappings
tool_exec<- function(in_params, out_params){

  ##################################################################################################### 
  ### Define input/output parameters
  #####################################################################################################
  efi = in_params[[1]]
  parm38 = in_params[[2]]
  parm42 = in_params[[3]]
  parm13 <- in_params[[4]]
  ##################################################################################################### 
  
  ### Read parameter files and change values
  
  #####################################################################################################
  ####EPICONT.DAT
  ####EFI Runoff volume / volume irrigation water appl
  EPICCONT<- file(paste('C:\\REPIC\\EPIC0810\\EPICCONT.DAT', sep=""))
  a_EPICCONT=readLines(EPICCONT)
  b_EPICCONT=read.table(EPICCONT, fill=TRUE)
  ###CHANGE THE VALUE
  b_EPICCONT[4,7]<-as.numeric(efi)
  b_EPICCONT[4,]<-sprintf("%3.2f", b_EPICCONT[4,])
  a_EPICCONT[4]<-sprintf("%8s%8s%8s%8s%8s%8s%8s%8s%8s%8s",b_EPICCONT[4,1],b_EPICCONT[4,2],b_EPICCONT[4,3],b_EPICCONT[4,4],
                b_EPICCONT[4,5],b_EPICCONT[4,6],
               b_EPICCONT[4,7],b_EPICCONT[4,8],b_EPICCONT[4,9],b_EPICCONT[4,10])
  writeLines(as.character(a_EPICCONT), paste('C:\\REPIC\\EPIC0810\\EPICCONT.DAT', sep=" ")) 
  ####PARM.DAT
  PARM<- file(paste('C:\\REPIC\\EPIC0810\\PARM.DAT', sep=""))
  a_PARM=readLines(PARM)
  ###CHANGE THE VALUE parm(38)
  # Hargreaves PET equation coefficient (0.0023-0.0032)
  #DECIMALS line 34
  y1<-substr(a_PARM[34],3,8)
  y2<-substr(a_PARM[34],12,16)
  y3<-substr(a_PARM[34],19,24)
  y4<-substr(a_PARM[34],27,32)
  y5<-substr(a_PARM[34],35,40)
  y6<-substr(a_PARM[34],44,48)
  y7<-substr(a_PARM[34],52,56)
  y8<-substr(a_PARM[34],58,64)
  y8<-as.numeric(parm38)
  y8<-substr(sprintf("%1.5f",as.numeric(y8)),1,8)
  y9<-substr(a_PARM[34],68,72)
  y10<-substr(a_PARM[34],77,84)
  ypar<-sprintf("%8s%8s%8s%8s%8s%8s%8s%8s%8s%8s",y1,y2,y3,y4,y5,y6,y7,y8,y9,y10)
  a_PARM[34]<-ypar
  #DECIMALS line 35
  ###CHANGE THE VALUE parm(42)
  # NRCS curve number index coefficient (0.5-1.5) 
  #regulates the effect of PET in driving the NRCS curve number retention parameter. 
  x1<-substr(a_PARM[35],6,8)
  x2<-substr(a_PARM[35],13,16)
  x2<-as.numeric(parm42)
  x2<-substr(sprintf("%1.2f",as.numeric(x2)),1,4)
  x3<-substr(a_PARM[35],21,24)
  x4<-substr(a_PARM[35],30,32)
  x5<-substr(a_PARM[35],38,40)
  x6<-substr(a_PARM[35],46,48)
  x7<-substr(a_PARM[35],50,56)
  x8<-substr(a_PARM[35],58,64)
  x9<-substr(a_PARM[35],69,72)
  x10<-substr(a_PARM[35],77,84)
  xpar<-sprintf("%8s%8s%8s%8s%8s%8s%8s%8s%8s%8s",x1,x2,x3,x4,x5,x6,x7,x8,x9,x10)
  a_PARM[35]<-xpar
  ###CHANGE THE VALUE parm(13)
  #Hargreaves PET equation exponent (0.5-0.6) original value = 0.5/. Modified to 0.6 to increase PET. 
  z1<-substr(a_PARM[32],4,8)
  z2<-substr(a_PARM[32],11,16)
  z3<-substr(a_PARM[32],21,24)
  z3<-as.numeric(parm13)
  z3<-substr(sprintf("%1.3f",as.numeric(z3)),1,5)
  z4<-substr(a_PARM[32],29,32)
  z5<-substr(a_PARM[32],36,40)
  z6<-substr(a_PARM[32],45,48)
  z7<-substr(a_PARM[32],53,56)
  z8<-substr(a_PARM[32],61,64)
  z9<-substr(a_PARM[32],68,72)
  z10<-substr(a_PARM[32],75,84)
  zpar<-sprintf("%8s%8s%8s%8s%8s%8s%8s%8s%8s%8s",z1,z2,z3,z4,z5,z6,z7,z8,z9,z10) 
  a_PARM[32]<-zpar
  writeLines(as.character(a_PARM), paste('C:\\REPIC\\EPIC0810\\PARM.DAT', sep=" ")) 
  return(out_params)
}  
  
  
  
  
  
  
  
  
  
  
  